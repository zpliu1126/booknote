#-*- coding:UTF-8 -*-
'''
author:zpliu
date:2019-07-08
email:1944532210@qq.com
descripte: Thie script is use for readind gene sequence from fasta file
usage: fastaread("fasta path")
'''
import re
from tqdm import tqdm
def fastaread(genesfile):
	with open(genesfile,'r') as allgenes:
		genes=allgenes.readlines()
	genelist={}
	for i in tqdm(range(0,len(genes)),desc="read genes file"):
		if re.match("^>",genes[i]):
			genes[i]=genes[i].strip("\n").strip(">")
			index1=i+1
			sequence=""
			while re.match("^[^>]",genes[index1]):
				sequence+=genes[index1].strip("\n")
				index1+=1
				#最后一行是序列，在less 过一行就不存在了
				if index1==len(genes):
					break
			genelist[genes[i]]=sequence
		else:
			continue
	return genelist
	


